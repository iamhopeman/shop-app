import{a as t}from"../chunks/entry.Bmxp6lam.js";export{t as start};
